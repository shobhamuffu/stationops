package com.example.guestbookbackend;

public class SaveComment {
    private String comment;

    public String getComment() {
        return comment;
    }
}
