package com.example.guestbookbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GuestbookBackendApplicationTests {

//    @Test
//    void contextLoads() {
//    }

}
